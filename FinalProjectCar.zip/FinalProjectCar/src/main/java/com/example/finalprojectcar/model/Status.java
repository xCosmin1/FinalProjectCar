package com.example.finalprojectcar.model;

public enum Status {
    BOOKED,
    AVAILABLE,
    UNAVAILABLE
}
