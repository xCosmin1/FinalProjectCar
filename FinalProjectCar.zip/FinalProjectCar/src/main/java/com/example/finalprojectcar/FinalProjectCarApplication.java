package com.example.finalprojectcar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalProjectCarApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinalProjectCarApplication.class, args);
    }

}
