package com.example.finalprojectcar.model;

public enum Position {
    MANAGER,
    EMPLOYEE
}
