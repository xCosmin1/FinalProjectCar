package com.example.finalprojectcar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalProjectCarApplicationTests {

    @Test
    void contextLoads() {
    }

}
